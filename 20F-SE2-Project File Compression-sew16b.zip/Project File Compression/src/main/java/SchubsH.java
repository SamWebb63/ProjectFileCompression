/*
* Author: Sam Webb
* Cooperated with Adam Garcia on this assignment
* Date: 11/28/2020
* Course: CS 375
* Program Name: Project File Compression
* Program Description:
* Compile: javac ShubsH.java
* Execute: java ShubsH input.txt | java BinaryDump <number>
*/

import java.io.File;

public class SchubsH
{
    private static final int R = 256;
    public static boolean logging = true;

    // trie node
    private static class Node implements Comparable<Node>
    {
        private final char ch;
        private final int freq;
        private final Node left, right;

        Node(char ch, int freq, Node left, Node right)
        {
            this.ch = ch;
            this.freq = freq;
            this.left = left;
            this.right = right;
        }

        // check to see if the node is a leaf node
        private boolean isLeaf()
        {
            assert(left == null && right == null) || (left != null && right != null);

            return (left == null && right == null);
        }

        // compare by frequancy
        public int compareTo(Node which)
        {
            return this.freq - which.freq;
        }
    }

    public static void err_println(String message)
    {
        if(logging)
            System.err.print(message);
    }

    public static void compress(BinaryIn in, BinaryOut out)
    {
        String s = in.readString();
        char[] input = s.toCharArray();

        int[] freq = new int[R];
        for(int i = 0; i < input.length; i++)
        {
            freq[input[i]]++;
        }

        Node root = buildTrie(freq);

        String[] t = new String[R];
        buildCode(t, root, "");

        writeTrie(root, out);
        err_println("writeTrie");

        out.write(input.length);
        err_println("Writing input length " + input.length);

        err_println("Encoding happily");

        for(int i = 0; i < input.length; i++)
        {
            String code = t[input[i]];
            err_println("Char " + input[i] + "");

            for(int j = 0; j < code.length(); j++)
            {
                if(code.charAt(j) == '0')
                {
                    out.write(false);
                    err_println("0");
                }
                else if(code.charAt(j) == '1')
                {
                    out.write(true);
                    err_println("1");
                }
                else
                {
                    throw new RuntimeException("Illegal state");
                }
            }

            err_println("");
        }

        out.flush();
    }

    private static Node buildTrie(int[] freq)
    {
        MinPQ<Node> pq = new MinPQ<Node>();

        for(char i = 0; i < R; i++)
        {
            if(freq[i] > 0)
                pq.insert(new Node(i, freq[i], null, null));
        }

        while(pq.size() > 1)
        {
            Node left = pq.delMin();
            Node right = pq.delMin();
            Node parent = new Node('\0', left.freq + right.freq, left, right);

            err_println("buildTrie parent " + left.freq + " " + right.freq);

            pq.insert(parent);
        }

        return pq.delMin();
    }

    private static void writeTrie(Node x, BinaryOut out)
    {
        if(x.isLeaf())
        {
            out.write(true);
            out.write(x.ch);

            err_println("T" + x.ch);

            return;
        }

        out.write(false);
        err_println("f");

        writeTrie(x.left, out);
        writeTrie(x.right, out);
    }

    private static void buildCode(String[] t, Node x, String s)
    {
        if(!x.isLeaf())
        {
            buildCode(t, x.left, s + '0');
            buildCode(t, x.right, s + '1');
        }
        else
        {
            t[x.ch] = s;

            err_println("buildCode " + x.ch + " " + s); 
        }
    }

    public static void main(String[] args)
    {       
        BinaryIn in = null;
        BinaryOut out = null;
        File currentFile;

        for(int i = 0; i < args.length; i++)
        {
            try 
            {
                currentFile = new File(args[i]);

                if(!currentFile.exists() || !currentFile.isFile())
                    System.out.println(args[i] + " could not be compressed because is was not a file");
                else if(currentFile.length() == 0)
                    System.out.println(args[i] + " could not be compressed because it was empty");
                else
                {
                    in = new BinaryIn(args[i]);
                    out = new BinaryOut(args[i] + ".hh");
                    compress(in, out);
                }
                    
            } finally
            {
                if(out != null)
                    out.close();
            }
        }       
        //else throw new RuntimeException("Illegal command line argument");              
    }
}