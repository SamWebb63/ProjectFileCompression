/**
 *  Program : TarN
 *  Author  : Sam Webb
 *  Date    : Fall 2020
 *  Course  : CS375 Software Engineering II
 * 
 *  Create an archive with two files
 *  Compile: mvn test
 *  java Tarsn archive-name file1 [file2 file3 ...]
 */

import java.io.File;
import java.io.IOException;

public class TarN
{

    static void tarit (String filename, String outName, BinaryOut out)
    {
        char space = (char) 225;

        try
        {
            File in1 = new File(filename);

            if(!in1.exists() || !in1.isFile())
                return;

            long filesize = in1.length();
            int filenamesize = filename.length();
            
            out.write(filenamesize);
            out.write(space);

            out.write(filename);
            out.write(space);

            out.write(filesize);
            out.write(space);

            System.out.println("archive " + outName);
            System.out.println("adding file " + filename + " (" + filesize + ")");
            BinaryIn bin1 = new BinaryIn(filename);

            while(!bin1.isEmpty())
            {
                out.write(bin1.readChar());
            }
           
        } 
        catch(RuntimeException ex)
        {
            System.out.println(ex.toString());
            System.out.println("File not found " + filename);
        }
    }

    public static void main(String[] args)
    {
        BinaryOut out = new BinaryOut(args[0]);
        int count = args.length;
        int i = 1;

        try
        {
            while(i < count)
            {
                tarit(args[i], args[0], out);
                i++;
            }
        }
        finally
        {
            if(out != null)
                out.close();
        }
    }
}