/*
* Author: Sam Webb
* Cooperated with Adam Garcia on this assignment
* Date: 11/28/2020
* Course: CS 375
* Program Name: Project File Compression
* Program Description:
* Compile: mvn test
* Excute: java Deshubs archive-name
*/

import java.io.IOException;
import java.io.File;

public class Deschubs
{
    // LZW Stuff
    private static final int R = 256;
    private static final int L = 4096;
    private static final int W = 12;

    public static boolean logging = true;

    // huffman trie node
    private static class Node implements Comparable<Node>
    {
        private final char ch;
        private final int freq;
        private final Node left, right;

        Node(char ch, int freq, Node left, Node right)
        {
            this.ch = ch;
            this.freq = freq;
            this.left = left;
            this.right = right;
        }

        // check to see if the node is a leaf node
        private boolean isLeaf()
        {
            assert(left == null && right == null) || (left != null && right != null);

            return (left == null && right == null);
        }

        // compare by frequancy
        public int compareTo(Node which)
        {
            return this.freq - which.freq;
        }
    }

    public static void err_print(String message)
    {
        if(logging)
            System.err.print(message);
    }

    public static void err_println(String message)
    {
        if(logging)
            System.err.print(message);
    }

    // ShubsH, does .hh
    public static void expandH(BinaryIn in, BinaryOut out) 
    {            
        Node root = readTrie(in);  
       
        int length = in.readInt();
       
        for (int i = 0; i < length; i++) 
        {            
            Node x = root;            
            while (!x.isLeaf()) 
            {                
                boolean bit = in.readBoolean(); 

                if (bit) 
                    x = x.right;               
                else     
                    x = x.left;            
            }            

            out.write(x.ch);        
        }        
        out.flush();    
    }

    // SchubsL, does .ll 
    public static void expandL(BinaryIn in, BinaryOut out)
    {
        String[] st = new String[L];
        int i;

        for(i = 0; i < R; i++)
            st[i] = "" + (char) i;

        st[i++] = "";

        int codeword = in.readInt(W);
        String val = st[codeword];

        while(true)
        {
            out.write(val);
            codeword = in.readInt(W);

            if(codeword == R)
                break;
            
            String s = st[codeword];

            if(i == codeword)
                s = val + val.charAt(0);
            
            if(i < L)
                st[i++] = val + s.charAt(0);
            
            val = s;
        }

        out.close();
    }

    // .hh stuff
    private static Node readTrie(BinaryIn in)
    {
        boolean isLeaf = in.readBoolean();

        if(isLeaf)
        {
            char x = in.readChar();

            err_println("t: " + x);

            return new Node(x, -1, null, null);
        }
        else
        {
            err_println("f");

            return new Node('\0', -1, readTrie(in), readTrie(in));
        }
    }


    public static void main(String[] args) throws IOException 
    {
        BinaryIn in = null;
        BinaryOut out = null;

        String filename = "";
        String filetype = "";  

        for(int i = 0; i < args.length; i++)
        {
            try 
            {
                for(int j = 0; j < (args[i].length() - 3); j++)
                filename = filename + args[i].charAt(j);
            
                for(int k = (args[i].length() - 3); k < args[i].length(); k++)
                    filetype = filetype + args[i].charAt(k);

                in = new BinaryIn(args[i]);
                out = new BinaryOut(filename);

                if(filename.length() == 0)
                {
                    System.out.println(args[i] + " could not be compressed because it was empty");
                }
                    

                System.out.println("filename: " + filename);
                System.out.println("filetype: " + filetype);
                
                // find out if Huffman or LZW and uncompress
                if(filetype.equals(".hh"))
                    expandH(in, out);
                else if(filetype.equals(".ll"))
                    expandL(in, out);
                else
                    System.out.println("Incorrect filetype"); 
            } 
            finally 
            {
                if(out != null)
                    out.close();
            }                         
        }
    }
}