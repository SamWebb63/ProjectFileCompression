/*
* Author: Sam Webb
* Cooperated with Adam Garcia on this assignment
* Date: 11/28/2020
* Course: CS 375
* Program Name: Project File Compression
* Program Description:
* Compile: mvn compile
* Excute: mvn test
*/

import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.After;
import org.apache.commons.io.FileUtils;
import java.util.*;
import java.util.Random;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import java.nio.file.Files;


public class FileCompressionTest
{
    public Boolean fileExists(String file)
    {
        File f = new File(file);
        return f.exists();
    }

    public void fileDelete(String file)
    {
        File f = new File(file);
        f.delete();
    }

    public Boolean compare(String file, String file2)
    {
        try
        {
            File src = new File(file);
            File destination = new File(file2);
            Boolean isEqual = FileUtils.contentEquals(src, destination);

            return isEqual;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    // Function from https://www.programiz.com/java-programming/examples/generate-random-string
    public String randomString() 
    {
        // create a string of all characters
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
        // create random string builder
        StringBuilder sb = new StringBuilder();
    
        // create an object of Random class
        Random random = new Random();
    
        // specify length of random string
        int length = 7;
    
        for(int i = 0; i < length; i++) 
        {
          // generate random index number
          int index = random.nextInt(alphabet.length());
    
          // get character specified by index
          // from the string
          char randomChar = alphabet.charAt(index);
    
          // append the character to string builder
          sb.append(randomChar);
        }

        return sb.toString();
    } 

    // SchubsL Stuff : Nothing new

    // Deschubes - T E S T I N G //
    
    // uncompress normal .hh file
    @Test
    public void normalDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest1" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest1" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH1.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // uncompress empty .hh file
    /*@Test
    public void emptyDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest2" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest2" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH2.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }*/

    // uncompress many amount of characters .hh file
    @Test
    public void manyCharsDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest3" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest3" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH3.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // non existant .hh
    /*@Test
    public void nonExistantDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest4" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest4" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH4.txt";
   
        assertFalse(fileExists(file));

        String[] args = {file};

        Deschubs.main(args);
    }*/

    // uncompress spaces and line breaks .hh file
    @Test
    public void manyThingsDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest5" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest5" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH5.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // no spaces .hh
    @Test
    public void noSpaceDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest6" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest6" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH6.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // lower case .hh
    @Test
    public void lowerDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest7" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest7" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH7.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // upper case .hh
    @Test
    public void upperDH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DHTest8" + File.separator + "file1.txt.hh";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DHTest8" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DH8.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // uncompress normal .ll file
    @Test
    public void normalDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest1" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest1" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL1.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // uncompress empty .ll file
    /*@Test
    public void emptyDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest2" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest2" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL2.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }*/

    // uncompress many amount of characters .ll file 
    @Test
    public void manyCharsDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest3" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest3" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL3.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // non existant .ll
    /*@Test
    public void nonExistantDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest4" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest4" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL4.txt";
   
        assertFalse(fileExists(file));

        String[] args = {file};

        Deschubs.main(args);
    }*/

    // uncompress spaces and line breaks .ll file
    @Test
    public void manyThingsDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest5" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest5" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL5.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // no spaces .ll
    @Test
    public void noSpacesDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest6" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest6" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL6.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // lower case .ll
    @Test
    public void lowerDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest7" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest7" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL7.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // upper case .ll
    @Test
    public void upperDL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DLTest8" + File.separator + "file1.txt.ll";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DLTest8" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "DL8.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        Deschubs.main(test);

        assertTrue(compare(fileAnswer, fileSolution));
    } 

    // incorrect file type
    @Test
    public void badTypeD() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "DTest1" + File.separator + "file1.txt.hl";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "DTest1" + File.separator + "file1.txt";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "D1.txt";
   
        String[] test = {file};

        assert(fileExists(file));

        Deschubs.main(test);
    }

    // SchubsH - T E S T I N G //

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream newOut = System.out;
    private final PrintStream newErr = System.err;
    
    // The file to be compressed is empty 
    @Test
    public void emptySourceFileH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest1" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest1" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H1.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    } 

    // Normal Case
    @Test
    public void normalTestH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest2" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest2" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H2.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }
    
    // The file to be compressed does not exist 
    @Test
    public void nonExistingSourceFileH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest3" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest3" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H3.hh";

        assertFalse(fileExists(file));

        String[] args = {file};

        SchubsH.main(args);
    }

    // The file to be compressed contains many things 
    @Test
    public void manyThingsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest4" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest4" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H4.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The user passes in the wrong amount of arguments
    @Test
    public void wrongArgumentsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest5" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest5" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H5.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The file to be compressed contains one really long word with no spaces
    @Test
    public void longWordH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest6" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest6" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H6.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The file to be compressed contains only lowercase characters
    @Test
    public void lowerCharsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest7" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest7" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H7.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The file to be compressed contains only uppercase characters
    @Test
    public void upperCharsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest8" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest8" + File.separator + "file1.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H8.hh";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsH.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // one dynamic
    @Test
    public void dynamicTestH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest17" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest17" + File.separator + "file1.txt.hh";
    
        String content = randomString();

        File txt = new File(file);
        
        txt.createNewFile();

        FileWriter CSL = new FileWriter(file);
        CSL.write(content);
        CSL.close();

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        String[] args = {file};
        SchubsH.main(args);
    }

    // Many files are empty
    @Test
    public void manyEmptyH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest9" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H9.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H9_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H9_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    } 

    // Many normal test files
    @Test
    public void manyNormalH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest10" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H10.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H10_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H10_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // Many files do not exist
    @Test
    public void manyNonExistH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest11" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H11.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H11_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H11_3.hh";
        
        String[] args = {file,file2,file3};

        assertFalse(fileExists(file));
        assertFalse(fileExists(file2));
        assertFalse(fileExists(file3));

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // Many files contain many things
    @Test
    public void manyManyThingsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest12" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H12.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H12_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H12_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // Many files have the wrong arguments
    @Test
    public void manyWrongArgsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest13" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H13.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H13_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H13_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    //Many files have long words
    @Test
    public void manyLongWordsH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest14" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H14.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H14_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H14_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // Many files have only lowercase
    @Test
    public void manyAllLowerH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest15" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H15.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H15_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H15_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // Many files have only uppercase
    @Test
    public void manyAllUpperH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest16" + File.separator + "file3.txt.hh";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H16.hh";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H16_2.hh";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "H16_3.hh";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsH.main(args);

        for(int i = 0; i < args.length; i++)
            assertTrue(compare(fileAnswer, fileSolution));
    }

    // many dynamic
    @Test
    public void manyDynamicTestH() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file1.txt.hh";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file2.txt.hh";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "HTest18" + File.separator + "file3.txt.hh";
    
        String content1 = randomString();
        String content2 = randomString();
        String content3 = randomString();

        File txt1 = new File(file);
        File txt2 = new File(file2);
        File txt3 = new File(file3);
        
        txt1.createNewFile();
        txt2.createNewFile();
        txt3.createNewFile();

        FileWriter CSL = new FileWriter(file);
        CSL.write(content1);
        CSL.close();

        FileWriter Tolk = new FileWriter(file2);
        Tolk.write(content2);
        Tolk.close();

        FileWriter Green = new FileWriter(file3);
        Green.write(content3);
        Green.close();

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        String[] args = {file, file2, file3};
        SchubsH.main(args);
    } 

    // SchubsL - T E S T I N G //
    
    // The file to be compressed is empty
    @Test
    public void emptySourceFileL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest1" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest1" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L1.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // Normal Case
    @Test
    public void normalTestL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest2" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest2" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L2.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }
    

    // The file to be compressed does not exist
    @Test
    public void nonExistingSourceFileL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest3" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest3" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L3.ll";

        assertFalse(fileExists(file));

        String[] args = {file};

        SchubsL.main(args);
    }

    // The file to be compressed contains many things
    @Test
    public void manyThingsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest4" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest4" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L4.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The user passes in the wrong amount of arguments
    @Test
    public void wrongArgsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest5" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest5" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L5.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    
    // The file to be compressed contains one really long word with no spaces
    @Test
    public void longWordL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest6" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest6" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L6.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // The file to be compressed contains only lowercase characters
    @Test
    public void lowerCharsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest7" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest7" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L7.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    
    // The file to be compressed contains only uppercase characters
    @Test
    public void upperCharsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest8" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest8" + File.separator + "file1.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L8.ll";
        
        String[] args = {file};

        assert(fileExists(file));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        SchubsL.main(args);

        assertTrue(compare(fileAnswer, fileSolution));
    }

    // one dynamic
    @Test
    public void dynamicTestL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest17" + File.separator + "file1.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest17" + File.separator + "file1.txt.ll";
    
        String content = randomString();

        File txt = new File(file);
        
        txt.createNewFile();

        FileWriter CSL = new FileWriter(file);
        CSL.write(content);
        CSL.close();

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);

        String[] args = {file};
        SchubsL.main(args);
    }

    
    // Many files are empty
    @Test
    public void manyEmptyL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest9" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L9.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L9_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L9_3.ll";
        
        String[] args = {file, file2, file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
            
    }

    // Many normal test 
    @Test
    public void manyNormalL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest10" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L10.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L10_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L10_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // Many files do not exist
    @Test
    public void manyNonExistantL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest11" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L11.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L11_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L11_3.ll";
        
        String[] args = {file,file2,file3};

        assertFalse(fileExists(file));
        assertFalse(fileExists(file2));
        assertFalse(fileExists(file3));

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // Many files contain many things
    @Test
    public void manyManyThingsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest12" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L12.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L12_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L12_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // Many files have the wrong arguments
    @Test
    public void manyWrongArgsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest13" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L13.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L13_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L13_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    //Many files have long words
    @Test
    public void manyLongWordsL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest14" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L14.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L14_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L14_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // Many files have only lowercase
    @Test
    public void manyOnlyLowerL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest15" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L15.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L15_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L15_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // Many files have only uppercase
    @Test
    public void manyOnlyUpperL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest16" + File.separator + "file3.txt.ll";
        String fileSolution = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L16.ll";
        String fileSolution2 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L16_2.ll";
        String fileSolution3 = "src" + File.separator + "files" + File.separator + "Solutions" + File.separator + "L16_3.ll";
        
        String[] args = {file,file2,file3};

        assert(fileExists(file));
        assert(fileExists(file2));
        assert(fileExists(file3));

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        SchubsL.main(args);

        for(int i = 0; i < args.length; i++)
        {
            assertTrue(compare(fileAnswer, fileSolution));
        }
    }

    // many dynamic
    @Test
    public void manyDynamicTestL() throws IOException
    {
        String file = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file1.txt";
        String file2 = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file2.txt";
        String file3 = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file3.txt";
        String fileAnswer = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file1.txt.ll";
        String fileAnswer2 = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file2.txt.ll";
        String fileAnswer3 = "src" + File.separator + "files" + File.separator + "LTest18" + File.separator + "file3.txt.ll";
    
        String content1 = randomString();
        String content2 = randomString();
        String content3 = randomString();

        File txt1 = new File(file);
        File txt2 = new File(file2);
        File txt3 = new File(file3);
        
        txt1.createNewFile();
        txt2.createNewFile();
        txt3.createNewFile();

        FileWriter CSL = new FileWriter(file);
        CSL.write(content1);
        CSL.close();

        FileWriter Tolk = new FileWriter(file2);
        Tolk.write(content2);
        Tolk.close();

        FileWriter Green = new FileWriter(file3);
        Green.write(content3);
        Green.close();

        if(fileExists(fileAnswer))
            fileDelete(fileAnswer);
        if(fileExists(fileAnswer2))
            fileDelete(fileAnswer2);
        if(fileExists(fileAnswer3))
            fileDelete(fileAnswer3);

        String[] args = {file, file2, file3};
        SchubsL.main(args);
    } 
}